package org.example.battleship;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hier entsteht das Spiel Schiffe versenken!");
    }
}
